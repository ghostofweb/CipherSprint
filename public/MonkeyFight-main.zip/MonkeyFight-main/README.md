## TypeSpeed Logic

WPM = (Correct class)/5/time(in mins)

accuracy = correct words/total words types * 100

Correct Characters
Incorrect Characters
Missed Words
Extra words